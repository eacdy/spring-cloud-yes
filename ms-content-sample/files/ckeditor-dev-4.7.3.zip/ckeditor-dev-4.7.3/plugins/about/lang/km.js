/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'km', {
	copy: 'រក្សាសិទ្ធិ &copy; $1។ រក្សា​សិទ្ធិ​គ្រប់​បែប​យ៉ាង។',
	dlgTitle: 'អំពី CKEditor',
	help: 'ពិនិត្យ $1 សម្រាប់​ជំនួយ។',
	moreInfo: 'សម្រាប់​ព័ត៌មាន​អំពី​អាជ្ញាបណញណ សូម​មើល​ក្នុង​គេហទំព័រ​របស់​យើង៖',
	title: 'អំពី CKEditor',
	userGuide: 'វិធី​ប្រើ​ប្រាស់ CKEditor'
} );
