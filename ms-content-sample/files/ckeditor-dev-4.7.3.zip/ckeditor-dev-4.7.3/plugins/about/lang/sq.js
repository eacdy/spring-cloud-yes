/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'sq', {
	copy: 'Të drejtat  e kopjimit &copy; $1. Të gjitha të drejtat e rezervuara.',
	dlgTitle: 'Rreth CKEditor',
	help: 'Kontrollo $1 për ndihmë.',
	moreInfo: 'Për informacione rreth licencave shih faqen tonë:',
	title: 'Rreth CKEditor',
	userGuide: 'Udhëzuesi i Shfrytëzuesit të CKEditor'
} );
