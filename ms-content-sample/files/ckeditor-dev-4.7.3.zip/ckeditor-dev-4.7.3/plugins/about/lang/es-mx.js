/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'es-mx', {
	copy: 'Derechos reservados &copy; $1. Todos los derechos reservados',
	dlgTitle: 'Acerca de CKEditor',
	help: 'Revisa $1 para ayuda.',
	moreInfo: 'Para información sobre la licencia por favor visita nuestro sitio web:',
	title: 'Acerca de CKEditor',
	userGuide: 'Guía de Usuario CKEditor'
} );
