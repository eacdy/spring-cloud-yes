/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'fo', {
	copy: 'Copyright &copy; $1. All rights reserved.',
	dlgTitle: 'Um CKEditor',
	help: 'Kekka $1 fyri hjálp.',
	moreInfo: 'Licens upplýsingar finnast á heimasíðu okkara:',
	title: 'Um CKEditor',
	userGuide: 'CKEditor Brúkaravegleiðing'
} );
