/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'af', {
	bold: 'Vet',
	italic: 'Skuins',
	strike: 'Deurgestreep',
	subscript: 'Onderskrif',
	superscript: 'Bo-skrif',
	underline: 'Onderstreep'
} );
