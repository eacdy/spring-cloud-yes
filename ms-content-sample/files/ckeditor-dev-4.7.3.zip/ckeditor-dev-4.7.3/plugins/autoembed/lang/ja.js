/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'autoembed', 'ja', {
	embeddingInProgress: '貼り付けられたURLを埋め込み中...',
	embeddingFailed: 'このURLは自動的に埋め込むことが出来ません。'
} );
